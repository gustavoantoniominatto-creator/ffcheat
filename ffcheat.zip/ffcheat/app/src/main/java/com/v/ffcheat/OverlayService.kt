package com.v.ffcheat
import android.app.*
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var wv: WebView? = null
    private var root: android.widget.FrameLayout? = null
    override fun onCreate() {
        super.onCreate(); startForeground(1001, Notification.Builder(this, "ov").setContentTitle("Painel").build())
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        if (Settings.canDrawOverlays(this)) addPanel()
    }
    override fun onStartCommand(i: Intent?, f: Int, s: Int) = START_STICKY
    override fun onBind(i: Intent?): IBinder? = null
    private fun addPanel() {
        root = android.widget.FrameLayout(this)
        wv = WebView(this).apply {
            setBackgroundColor(0); settings.javaScriptEnabled = true
            addJavascriptInterface(Bridge(), "V"); webViewClient = WebViewClient()
            loadUrl("file:///android_asset/panel.html")
        }
        root?.addView(wv, android.widget.FrameLayout.LayoutParams(750, 750))
        val lp = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = 100; y = 200 }
        wm.addView(root, lp)
    }
    inner class Bridge {
        @JavascriptInterface fun set(k: String, v: Any) { Config.set(this@OverlayService, k, v) }
        @JavascriptInterface fun minimize() { android.os.Handler(mainLooper).post { root?.visibility = android.view.View.GONE } }
        @JavascriptInterface fun close() { stopSelf() }
    }
}