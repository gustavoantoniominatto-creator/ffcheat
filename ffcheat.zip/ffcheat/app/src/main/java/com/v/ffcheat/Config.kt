package com.v.ffcheat
import android.content.Context
object Config {
    private const val P = "ffcheat"
    private fun sp(c: Context) = c.getSharedPreferences(P, Context.MODE_PRIVATE)
    fun set(c: Context, k: String, v: Any) {
        val e = sp(c).edit()
        when (v) { is Boolean -> e.putBoolean(k, v); is Int -> e.putInt(k, v); is Float -> e.putFloat(k, v); is String -> e.putString(k, v) }
        e.apply()
    }
    fun bool(c: Context, k: String, d: Boolean = false) = sp(c).getBoolean(k, d)
    fun int(c: Context, k: String, d: Int = 0) = sp(c).getInt(k, d)
}