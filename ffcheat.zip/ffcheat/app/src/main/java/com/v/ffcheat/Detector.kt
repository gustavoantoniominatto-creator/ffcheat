package com.v.ffcheat
import android.content.Context
import android.graphics.Bitmap
import android.graphics.RectF
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.support.common.FileUtil
import java.nio.ByteBuffer
import java.nio.ByteOrder
class Detector(private val ctx: Context) {
    private var itp: Interpreter? = null
    private var size = 320
    fun load(): Boolean = try {
        val m = FileUtil.loadMappedFile(ctx, "model.tflite")
        itp = Interpreter(m, Interpreter.Options().apply { numThreads = 4 })
        size = itp!!.getInputTensor(0).shape()[1]
        true
    } catch (t: Throwable) { false }
    fun close() { itp?.close(); itp = null }
    fun detect(frame: Bitmap, fovR: Float, minConf: Float): RectF? {
        val i = itp ?: return null
        val rs = Bitmap.createScaledBitmap(frame, size, size, true)
        val buf = ByteBuffer.allocateDirect(size*size*3*4).order(ByteOrder.nativeOrder())
        val px = IntArray(size*size); rs.getPixels(px,0,size,0,0,size,size)
        for (p in px) { buf.putFloat(((p shr 16) and 0xFF)/255f); buf.putFloat(((p shr 8) and 0xFF)/255f); buf.putFloat((p and 0xFF)/255f) }
        buf.rewind()
        val shape = i.getOutputTensor(0).shape()
        val chFirst = shape[1] == 84
        val out: Array<Array<FloatArray>> = if (chFirst) Array(1){Array(84){FloatArray(shape[2])}} else Array(1){Array(shape[1]){FloatArray(84)}}
        try { i.run(buf, out) } catch (_: Throwable) { return null }
        val f = out[0]; val n = if (chFirst) shape[2] else shape[1]
        var best: RectF? = null
        for (k in 0 until n) {
            val person = if (chFirst) f[4][k] else f[k][4]
            if (person < minConf) continue
            val cx = (if (chFirst) f[0][k] else f[k][0]) * (frame.width.toFloat()/size)
            val cy = (if (chFirst) f[1][k] else f[k][1]) * (frame.height.toFloat()/size)
            val w  = (if (chFirst) f[2][k] else f[k][2]) * (frame.width.toFloat()/size)
            val h  = (if (chFirst) f[3][k] else f[k][3]) * (frame.height.toFloat()/size)
            val dx = cx - frame.width/2f; val dy = cy - frame.height/2f
            if (dx*dx + dy*dy > fovR*fovR) continue
            best = RectF(cx-w/2f, cy-h/2f, cx+w/2f, cy+h/2f)
        }
        return best
    }
}